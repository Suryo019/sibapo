<div class="flex items-center border bg-gray-10 rounded-[10px] w-full lg:w-64 h-9 px-5">
    <input type="text" id="search" placeholder="{{ $slot }}" class="flex-grow outline-none bg-transparent">
    <span class="bi bi-search text-gray-700"></span>
</div>